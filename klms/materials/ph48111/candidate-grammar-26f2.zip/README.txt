Controlled course archive

Course: PH.48111 자동 이론 구성 실습
Announcement: ph48111-ann-03
File: candidate-grammar-26f2.zip

This bundle is a teaching release. Keep the source filename and announcement
identifier in every derived ledger. Machine-generated candidates retain their
original revision numbers, including isolated candidates.
