M32 long-baseline propagation release r6

Course: PH.45130 양자중력
Announcement: ph45130-ann-05

Reproduce r5 and r6 independently before reporting the joint mass–coupling
posterior. The two C records are calibration controls and must not be counted
as independent propagation events. Preserve the r5 alias in the submitted
table diff even when the r6 upper bound is tighter.
