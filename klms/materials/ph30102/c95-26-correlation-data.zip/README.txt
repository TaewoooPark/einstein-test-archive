Controlled course archive

Course: PH.30102 양자역학 III
Announcement: ph30102-ann-05
File: c95-26-correlation-data.zip

This bundle is a teaching release. Keep the source filename and announcement
identifier in every derived ledger. Machine-generated candidates retain their
original revision numbers, including isolated candidates.
