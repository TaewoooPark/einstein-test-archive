Controlled course archive

Course: PH.45320 정적 우주론
Announcement: ph45320-ann-05
File: extinction-x7.zip

This bundle is a teaching release. Keep the source filename and announcement
identifier in every derived ledger. Machine-generated candidates retain their
original revision numbers, including isolated candidates.
