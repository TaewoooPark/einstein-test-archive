Brovary plate reduction bundle · release r3

Course: PH.40121 일반상대성이론 II
Announcement: ph40121-ann-03
Observation date: 1914-08-21
Registered result: 1.75 ± 0.19 arcsec

The r3 release expands the dust mask at the outer edge of plate B-17 and
repeats the centroid reduction for S-041 and S-044. Both r2 and r3 remain
accepted by the course regression service; completed work need not be rerun.

Files
  plate-reduction-r3.csv  reduced star rows in plate coordinates
  plate-manifest.json     controlled release metadata
  revision-ledger.json    three-step correction lineage
  reduction-notes.txt     column notes and weighted-fit instructions
