brovary-plates-r3.zip
PH.40121 General Theory of Relativity II: Extended Adapted Coordinates and the Standard Table
Fall 2026 course data package. See KLMS for the current assignment instructions.
