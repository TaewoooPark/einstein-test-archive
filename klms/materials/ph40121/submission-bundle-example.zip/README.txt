KLMS final submission bundle example

Course: PH.40121 일반상대성이론 II
Announcement: ph40121-ann-08

Replace the placeholder report with a searchable PDF. Preserve every filename
listed in artifact-manifest.json, then add a SHA-256 value for each final file.
The example ledger intentionally includes an isolated candidate. Do not remove
it when adapting the template; rejected lineage is part of the audit record.
